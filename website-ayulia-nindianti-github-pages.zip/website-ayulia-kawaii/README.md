# Website Ayulia Nindianti ♡
Tema kawaii, pastel, feminin, dan modern.

Isi: profil Ayulia Nindianti, Rekam Medis, Politeknik Cendrawasih Palu; hobi kulineran, jalan-jalan, membuat kue; My Little Things: coffee, sunset, taking photos.

Upload `index.html`, `style.css`, dan `script.js` ke repository GitHub, lalu aktifkan Settings → Pages → Deploy from a branch → main → /(root).
